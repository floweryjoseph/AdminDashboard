import React from 'react';
import classes from '../modules/viewCategory.module.scss'
const ViewCategory = () => {
  return (
    <div className={classes.viewCategory}>
    
     <h1>View Category</h1>
    </div>
  );
};

export default ViewCategory;
