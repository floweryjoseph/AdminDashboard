import classes from '../modules/login.module.scss'

const Login = () => {
  return (
    <div className={classes.login}>
      
    </div>
  )
}

export default Login
