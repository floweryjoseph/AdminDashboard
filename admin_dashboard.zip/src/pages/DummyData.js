export const userData = [
    {
      name: 'Jan',
      "Active User": 4000,
      
    },
    {
      name: 'Feb',
      "Active User": 3000,
     
    },
    {
      name: 'Mar',
      "Active User": 2000,
     
    },
    {
      name: 'Apr',
      "Active User": 2780,
      
    },
    {
      name: 'May',
      "Active User": 1890,
      
    },
    {
      name: 'June',
      "Active User": 2390,
      
    },
    {
      name: 'July',
      "Active User": 3490,
    
    },
    {
      name: 'Aug',
      "Active User": 3600,
      
    },
    {
      name: 'Sep',
      "Active User": 5000,
     
    },
    {
      name: 'Oct',
      "Active User": 4000,
     
    },
    {
      name: 'Nov',
      "Active User": 1780,
      
    },
    {
      name: 'Dec',
      "Active User": 2890,
      
    },
    
  ];
  