import classes from '../modules/widgetLarge.module.scss'

const WidgetLarge = () => {
  return (
    <div className={classes.widgetLarge}>
      Large
    </div>
  )
}

export default WidgetLarge
