import classes from '../modules/single.module.scss'
const Single = () => {
  return (
    <div className={classes.single}>
      
    </div>
  )
}

export default Single
