import classes from '../modules/newUser.module.scss'
const NewUser = () => {
  return (
    <div className={classes.newUser}>
   <h1>New User</h1> 
    </div>
  )
}

export default NewUser
