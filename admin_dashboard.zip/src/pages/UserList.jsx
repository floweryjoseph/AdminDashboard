import classes from '../modules/userList.module.scss'
const UserList = () => {
  return (
    <div className={classes.userList}>
      <h1>datatable</h1>
    </div>
  )
}

export default UserList
