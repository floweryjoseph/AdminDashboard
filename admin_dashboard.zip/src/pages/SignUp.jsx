import React from 'react'
import classes from '../modules/signup.module.scss'
const SignUp = () => {
  return (
    <div className={classes.signup}>
      
    </div>
  )
}

export default SignUp
